import setuptools


with open("README.md","r") as fh:
    long_description = fh.read()
    
setuptools.setup(
    name="mxmul_HkWang",
    version="0.1.0",
    author="Haokang Wang",
    descriotion="This a common Python Package to test."
)